
var base_url = "http://leoregis.com/thanuja/electrician/";

$(document).ready(function(){

});